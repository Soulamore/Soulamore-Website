# 📜 Antigravity Operational Protocol (v1.0)

This protocol defines the behavioral and documentation standards for the **Antigravity** agent within the Soulamore project.

---

## 1. 📂 Documentation & Reporting
All technical reports, audits, and handoff documents must be categorized by the acting agent.

- **Primary Directory**: `reports/ADITYA/`
- **Agent Lanes**:
  - `ANTIGRAVITY/`: Exclusive domain for Antigravity-specific research and handoffs.
  - `CODEX/`: Reserved for UI/UX stabilization and shared project standards.
  - `QWEN/` / `CURSOR/` / `KILOCODE/`: Dedicated lanes for respective agents.

---

## 2. 🏷️ Naming Conventions (Narrative Specs)
Reports must follow the chronological Narrative prefix pattern:
`[INDEX]_[YYYY-MM-DD]_[AGENT]_Spec_[SUBJECT].md`

*Example*: `059_2026-03-31_ANTIGRAVITY_Spec_Ghost_Logout.md`

---

## 3. 🤖 Identity & Boundaries
- **Identity**: Explicitly acknowledge as **Antigravity** when asked.
- **Lane Integrity**: Never write reports to another agent's folder (e.g., `CODEX`) unless explicitly requested for a cross-agent "Master" specification.
- **Socratic Gate**: Always verify high-impact changes (UI regressions, payment logic) before execution.

---

## 4. 🛠️ Narrative Handoff Standards (SCSC)
Handoff reports must be built as a **Self-Contained Session Context**:
1. **Visual Storytelling**: Describe the "feeling" and "visual impact" of bugs.
2. **Zero-Error Engineering Guts**: Full absolute paths, Mermaid logic gates, and exact logic edits.
3. **Model Compatibility**: Explicitly target "Qwen-level" precision for non-chat agents.
4. **The "Big 11" Pillars**: Enforce the constant rules (0.15s snapshots, 42px Pills, live stats).

---

## 5. 🧠 Persistent Context
Maintain the `protocol.md` in the session's brain directory to ensure continuity across context windows.
